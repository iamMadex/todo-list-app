/*This to-do application was created for week 2 task.
  
  NAME: NNAEBIYITE EJIKE-OBUOHA

  PATH: PHYSICAL INTERN
 
 */


//Display Date
var date = new Date();
var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

var year = new Date();

var dateNumber = new Date();

var day = new Date();
var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

document.getElementById("day").innerHTML = (days[day.getDay()] + ", " + dateNumber.getDate() + " " + months[date.getMonth()] + " " + year.getFullYear());

//Live analog clock function
function startTime() {
    var today = new Date();
    var h = today.getHours();
    var m = today.getMinutes();
    var s = today.getSeconds();
    m = checkTime(m);
    s = checkTime(s);
    document.getElementById("time").innerHTML = h + ":" + m + ":" + s;
    var t = setTimeout(startTime, 500);
}


function checkTime(i) {
    if (i < 10) {
        i = "0" + i;
    } // add zero in front of numbers < 10
    return i;
}

//Code to create todo list.
let form = document.getElementById("form");
let itemList = document.getElementById("items");

form.addEventListener("submit", createTodo);

function createTodo(event) {
    event.preventDefault();

    //Get user to-do input;
    let userInput = document.getElementById("userInput").value;

    //check for user input

    //If valid
    if (userInput != '') {
        //Create new list item
        let li = document.createElement("li");

        //Create new input form to hold todo list
        let inputForm = document.createElement("input");
        inputForm.className = "list-group-item";
        inputForm.value = userInput;
        inputForm.setAttribute("disabled", "");

        //Create edit button;
        let editButton = document.createElement("button");
        editButton.id = "buttons";
        editButton.className = "fa fa-pencil-square-o fa-1.8x";
        console.log(editButton);

        //Create a check button to indicate a task has been completed
        let checkButton = document.createElement("button");
        checkButton.id = "buttons";
        checkButton.className = "fa fa-check-square-o";

        //create remove button
        let removeButton = document.createElement("button");
        removeButton.id = "buttons";
        removeButton.className = "fa fa-trash";

        //create a break tag
        let breakButton = document.createElement("br");

        //Add input form to the list element;
        li.appendChild(inputForm);
        li.appendChild(removeButton);
        li.appendChild(editButton);
        li.appendChild(checkButton);

        //Add created list to created todo list
        itemList.appendChild(li);
        itemList.appendChild(breakButton);

        //Clear input form
        function myFunction() {
            document.getElementById("form").reset();
        }

        myFunction();

        //Create what happens when edit, delete or check buttons are clicked
        li.addEventListener("click", function (event) {

            //For delete button
            if (event.target.className == "fa fa-trash") {
                if (confirm("Are you sure?")) {
                    this.remove();
                }

            //For check button
            } else if (event.target.className == "fa fa-check-square-o") {
                console.log(this.childNodes[0]);
                this.childNodes[0].style.color = "red";
                this.childNodes[0].style.textDecoration = "line-through";
                this.childNodes[0].style.fontStyle = "italic";

            //For edit button
            } else if (event.target.className == "fa fa-pencil-square-o fa-1.8x") {

                let message = prompt("Edit To-do: ", "");
                inputForm.value = message;
            }
        });
    }
    //If user input is invalid
    else {
        alert("Cannot add an empty task to list.");
    }
}